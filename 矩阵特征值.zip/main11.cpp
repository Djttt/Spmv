#include <stdio.h>               // printf
#include <stdlib.h>              // EXIT_FAILURE
#include <hip/hip_runtime_api.h> // hipMalloc, hipMemcpy, etc.
#include <hip/hip_runtime.h>
#include <hip/hcc_detail/hip_complex.h>
#include <math.h>
#include <sys/time.h>

#define LAPACK_COMPLEX_STRUCTURE
#define HAVE_LAPACK_CONFIG_H
#include "lapacke.h"

#define WARMUP
#define ACCURACY_CHECK

// �����ʱ��
struct my_timer
{
    struct timeval start_time, end_time;
    double time_use; // us
    void start(){
		gettimeofday(&start_time, NULL);
    }
    void stop(){
		gettimeofday(&end_time, NULL);
		time_use = (end_time.tv_sec-start_time.tv_sec)*1.0e6 + end_time.tv_usec-start_time.tv_usec;
    }	
};

#define HIP_CHECK(stat)                                                    \
{                                                                          \
	if(stat != hipSuccess)                                                 \
	{                                                                      \
		std::cerr << "Error: hip error in line " << __LINE__ << std::endl; \
		exit(-1);                                                          \
	}                                                                      \
}		

double rand_double(int min,int max)
{
    return min + (int)max * rand()%100 / double((101));
}

typedef enum solverEigMode_ {
	solverEigMode_vector,
	solverEigMode_novector
}solverEigMode;

typedef enum solverFillMode_ {
	solverFillMode_lower,
	solverFillMode_upper
}solverFillMode;

// Hermite��������ֵ��⺯����������
void solverDnZheevd(solverEigMode jobz,
                    solverFillMode uplo,
                    int n,
                    hipDoubleComplex *d_A,
                    int lda,
                    double *d_W, 
                    int *execInfo);
					
// Hermite��������ֵ��⺯������ʵ��
void solverDnZheevd(solverEigMode jobz,
                    solverFillMode uplo,
                    int n,
                    hipDoubleComplex *d_A,
                    int lda,
                    double *d_W, 
                    int *execInfo)
{
	/*
	   function block
	*/
	*devInfo = 0;
	
	return;
}

int main(int argc, char** argv)
{
	if( argc != 5) {
		printf("eigenvalue test, Usage: ./eigValueTest eigMode fillMode matrixSize iter_num \n");
		exit(-1);
	}
	solverEigMode  jobz = solverEigMode(int(atoi(argv[1])));
	solverFillMode uplo = solverFillMode(int(atoi(argv[2])));
	int m   = int(atoi(argv[3]));
	int lda = m;
	int iter_num = int(atoi(argv[4]));
	
	printf("jobz:%d, uplo:%d, m:%d, iter_num:%d\n", jobz, uplo, m, iter_num);

	// ��ʼ��Hermite����A - host��
	hipDoubleComplex *A = (hipDoubleComplex*)malloc(lda*m*sizeof(hipDoubleComplex));
	assert(A != NULL);
	lapack_complex_double *lapack_A = (lapack_complex_double*)malloc(lda*m*sizeof(lapack_complex_double));
	assert(lapack_A != NULL);
	double *lapack_W = (double*)malloc(m * sizeof(double));
	assert(lapack_W != NULL);
	char lapack_jobz;
	char lapack_uplo;
	
	/*
	lapack_complex_double test[16] = {
           { 3.40,  0.00}, { 0.00,  0.00}, { 0.00,  0.00}, { 0.00,  0.00},
           {-2.36,  1.93}, { 6.94,  0.00}, { 0.00,  0.00}, { 0.00,  0.00},
           {-4.68, -9.55}, { 8.13,  1.47}, {-2.14,  0.00}, { 0.00,  0.00},
           { 5.37,  1.23}, { 2.07,  5.78}, { 4.68, -7.44}, {-7.42,  0.00}
        };
	*/
	
	if(uplo == solverFillMode_lower){
		for(int i = 0; i < m; i++)	{
			for(int j = 0; j < m; j++){
				if(i >= j){
					A[i*lda+j].x = rand_double(0, 10);
					A[i*lda+j].y = rand_double(0, 10);
					// A[i*lda+j].x = test[i*lda+j].real;
					// A[i*lda+j].y = test[i*lda+j].imag;
				}else{
					A[i*lda+j].x = 0.0;
					A[i*lda+j].y = 0.0;	
				}
				lapack_A[j*lda+i].real = A[i*lda+j].x;
				lapack_A[j*lda+i].imag = A[i*lda+j].y;
			}
		}	
		lapack_uplo = 'L';
	}else if(uplo == solverFillMode_upper){
		for(int i = 0; i < m; i++)	{
			for(int j = 0; j < m; j++){
				if(i <= j){
					A[i*lda+j].x = rand_double(0, 10);
					A[i*lda+j].y = rand_double(0, 10);
				}else{
					A[i*lda+j].x = 0.0;
					A[i*lda+j].y = 0.0;
				}
				lapack_A[j*lda+i].real = A[i*lda+j].x;
				lapack_A[j*lda+i].imag = A[i*lda+j].y;
			}
		}	
		lapack_uplo = 'U';
	}else {
		printf("not valid parameter!\n");
		exit(-1);
	}
	
	if(jobz == solverEigMode_vector){
		lapack_jobz = 'V';
	}else if(jobz == solverEigMode_novector){
		lapack_jobz = 'N';
	}else{
		printf("not valid parameter!\n");
		exit(-1);
	}
	
	// ��ʼ��Hermite����A - device��
	hipDoubleComplex *d_A;
	HIP_CHECK( hipMalloc((void**) &d_A, lda * m * sizeof(hipDoubleComplex)) );
	HIP_CHECK( hipMemcpy(d_A, A, lda * m * sizeof(hipDoubleComplex), hipMemcpyHostToDevice) );
	
	// ����device���ڴ�
	double *d_W;
	HIP_CHECK( hipMalloc((void**) &d_W, m * sizeof(double)) );
	double *h_W = (double*)malloc(m*sizeof(double));
	assert(h_W != NULL);
	// host��ָ��
	int devInfo;
	
	// Hermite��������ֵ��⺯������
	
#ifdef WARMUP
	solverDnZheevd(jobz, uplo, m, d_A, lda, d_W, &devInfo);
	if(devInfo != 0){
		printf("eigvalue calculates failed!\n"); 
		exit(-1);
    }
#endif
	
	double sum_costs = 0.0;
	my_timer timer1;
	for(int index = 0; index < iter_num; index++){
		// �豸�����ݻָ�
		HIP_CHECK( hipMemcpy(d_A, A, lda * m * sizeof(hipDoubleComplex), hipMemcpyHostToDevice) );
		// ִ�к���
		hipDeviceSynchronize();
		timer1.start();
		solverDnZheevd(jobz, uplo, m, d_A, lda, d_W, &devInfo);
		hipDeviceSynchronize();
		// ��ʱ��¼
		sum_costs += timer1.time_use;
	}	
	
	if(devInfo != 0){
		printf("eigvalue calculates failed!\n"); 
		exit(-1);
    }
	
	// Copy eigvalue������ - device-to-host
	printf("eigvalue exec averages costs(ms): %.6f ms\n", sum_costs/iter_num/1000.0);
	HIP_CHECK( hipMemcpy(h_W, d_W, m * sizeof(double), hipMemcpyDeviceToHost) );
		
#ifdef ACCURACY_CHECK
	int info = LAPACKE_zheevd( LAPACK_COL_MAJOR, lapack_jobz, lapack_uplo, m, lapack_A, lda, lapack_W);
	/* Check for convergence */
	if( info > 0 ) {
			printf( "The algorithm failed to compute eigenvalues.\n" );
			exit( 1 );
	}
	// Accuracy check
	for(int index = 0; index < m; index++)
	{
		double abs_diff = fabs(lapack_W[index] - h_W[index]);
		if(abs_diff > 1.0e-7)
		{
			printf("index:%d, lapack_W:%.6f, h_W:%.6f\n", index, lapack_W[index], h_W[index]);
            printf("Failed verification,please check your code\n");
            exit(-1);
		}
	}
	printf("check passed!\n");
#endif	

	// �洢��Դ�ͷ�
	free(A);
	free(lapack_A);
	free(h_W);
	free(lapack_W);
	
	hipFree(d_A);
	hipFree(d_W);
	
	return 0;
}

