#include<iostream>
#include <hip/hip_runtime_api.h> // hipMalloc, hipMemcpy, etc.
#include <stdio.h>            // printf
#include <stdlib.h>           // EXIT_FAILURE
#include <hip/hip_runtime.h>
extern double* hX;
extern double* hY;
extern double* value;
extern int* colindex;
extern int* rowptr;
extern int a;
enum sparse_operation {operation_none=0,operation_transpose=1} ;

#define HIP_CHECK(stat)                                                        \
    {                                                                          \
        if(stat != hipSuccess)                                                 \
        {                                                                      \
            std::cerr << "Error: hip error in line " << __LINE__ << std::endl; \
            exit(-1);                                                          \
        }                                                                      \
    }
    
__global__ void device_sparse_spmv(int        trans,
               const int               alpha,
	       const int               beta,
                     int               m,
                     int               n,
               const int*              rowptr,
	       const int*              colindex,
	       const double*           value,
               const double*           x,
                     double*           y
			)
{
        int tid = threadIdx.x + blockDim.x * blockIdx.x;
    	double y0 = 0;
        if(tid < m) {
        for (int j = rowptr[tid]; j < rowptr[tid + 1]; j++) {
        y0 += value[j] * x[colindex[j]];
    	}
         y[tid] = alpha * y0 + beta * y[tid];  
        }   
}


__global__ void device_sparse_spmv2(int        trans,
               const int               alpha,
	       const int               beta,
                     int               m,
                     int               n,
               const int*              rowptr,
	       const int*              colindex,
	       const double*           value,
               const double*           x,
                     double*           y
			)
{      
        int thread_id = threadIdx.x + blockDim.x * blockIdx.x;
        int row = thread_id >> 2;
        int lane = threadIdx.x & (3);
        double sum = 0;
        
        if(row < m) {
        	int row_start = rowptr[row];
        	int row_end = rowptr[row + 1];
    		for(int j = row_start + lane; j < row_end; j += 4) {
    			sum += value[j] * x[colindex[j]];
			}
              for(int i = 2; i > 0; i >>=1) 
                    	sum += __shfl_down(sum, i, 4);
			if(lane == 0) 
				y[row] += sum;
		}   
}


void  sparse_spmv(int                  htrans,
               const int               halpha,
	       const int               hbeta,
                     int               hm,
                     int               hn,
               const int*              hrowptr,
	       const int*              hcolindex,
	       const double*           hvalue,
               const double*           hx,
                     double*           hy
			)
{
		int blocks = hm / 128 + 1;
        int threads = 512;
        hipLaunchKernelGGL(device_sparse_spmv2,blocks,threads, 0, 0, htrans,halpha,hbeta,hm,hn,hrowptr,hcolindex,hvalue,hx,hy);
}